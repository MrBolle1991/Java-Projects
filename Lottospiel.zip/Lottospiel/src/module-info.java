/**
 * 
 */
/**
 * 
 */
module Lernfeld_11 {
	requires java.desktop;
}